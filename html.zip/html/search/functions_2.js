var searchData=
[
  ['sculptor',['Sculptor',['../classSculptor.html#a014e3ef5517bf0e9d9e14486b6ac6433',1,'Sculptor']]],
  ['setcolor',['setColor',['../classSculptor.html#af1d69da01379874b0dfd6454787cb562',1,'Sculptor']]]
];
