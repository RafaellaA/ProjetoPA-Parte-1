var searchData=
[
  ['r',['r',['../structVoxel.html#a06872ec79b836120b551a848968c0f1b',1,'Voxel']]]
];
